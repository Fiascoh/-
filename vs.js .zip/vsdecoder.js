// ======================================================================
// VSEncoder v3 — Browser Decoder
// ======================================================================
//
// Decodes payloads encoded by vsencoder.py v3 (240-char ALPHABET,
// 365 languages, 4-char overhead: 1 flag + 3 language markers).
//
// Usage in browser console:
//   const decoded = await VSEncoder.decode("󠄾󠄀󠄶...");
//
// Usage as userscript (Tampermonkey/Greasemonkey):
//   // @grant none
//   const decoded = await VSEncoder.decode(selectedText);
//
// The decoder regenerates language profiles on-the-fly using a port of
// Python's Mersenne Twister (random.Random), so no lookup table is
// needed. The only async part is SHA-256 (Web Crypto API).
//
// Compatible with v3 payloads ONLY. v1/v2 payloads are not decodable.
// ======================================================================

const VSEncoder = (function () {
    'use strict';

    // ======= CONSTANTS ===================================================

    // 240-char ALPHABET (must match generate_language_table.py exactly)
    // ASCII printable (95) + Latin-1 Supplement (96) + Latin Extended-A (49)
    const ALPHABET = (function () {
        let s = '';
        for (let cp = 0x20; cp <= 0x7E; cp++) s += String.fromCharCode(cp);  // 95
        for (let cp = 0xA0; cp <= 0xFF; cp++) s += String.fromCharCode(cp);  // 96
        for (let cp = 0x100; cp <= 0x130; cp++) s += String.fromCodePoint(cp); // 49
        return s;
    })();

    const ALPHABET_INDEX = {};
    for (let i = 0; i < ALPHABET.length; i++) {
        ALPHABET_INDEX[ALPHABET[i]] = i;
    }

    const VS_BASE = 0xE0100;

    // Flag chars
    const FLAG_RAW = '\u034F';  // COMBINING GRAPHEME JOINER
    const FLAG_URL = '\u200C';  // ZERO WIDTH NON-JOINER
    const FLAG_TO_NORMALIZED = {};
    FLAG_TO_NORMALIZED[FLAG_RAW] = false;
    FLAG_TO_NORMALIZED[FLAG_URL] = true;

    // 14 language marker ZWC chars
    const LANG_MARKER_CODEPOINTS = [
        0x200B, 0x200D, 0x200E, 0x200F, 0x2060, 0x2061, 0x2062, 0x2063,
        0x2064, 0x115F, 0x1160, 0x3164, 0xFFA0, 0xE007F
    ];
    const LANG_MARKERS = LANG_MARKER_CODEPOINTS.map(cp => String.fromCodePoint(cp));
    const LANG_MARKER_SET = new Set(LANG_MARKERS);
    const LANG_MARKER_CP_TO_INDEX = {};
    for (let i = 0; i < LANG_MARKER_CODEPOINTS.length; i++) {
        LANG_MARKER_CP_TO_INDEX[LANG_MARKER_CODEPOINTS[i]] = i;
    }

    // Dimension variant counts (must match generator)
    const TRAVERSAL_COUNT = 7;
    const CHUNK_SIZE_COUNT = 7;
    const CHUNK_INTERNAL_COUNT = 7;
    const POSITION_COUNT = 7;
    const CHUNK_SIZE_VALUES = [1, 3, 4, 5, 7, 8, 13];


    // ======= MERSENNE TWISTER (port of Python's random.Random) ==========
    //
    // Python's random.Random uses the Mersenne Twister (MT19937) with a
    // specific seeding algorithm (init_by_array). This port must produce
    // the EXACT same sequence of random numbers as Python for a given
    // seed, otherwise the language profiles won't match.
    //
    // Key details:
    //   - 624-element state array of 32-bit unsigned ints
    //   - init_by_array: standard MT seeding from the original paper
    //   - Seed int is converted to 32-bit words (LITTLE-ENDIAN) before
    //     passing to init_by_array
    //   - getrandbits(k): for k <= 32, returns one uint32 >> (32 - k)
    //   - _randbelow(n): rejection sampling using getrandbits(bit_length(n))
    //   - shuffle: Fisher-Yates using _randbelow

    const MT_N = 624;
    const MT_M = 397;
    const MT_MATRIX_A = 0x9908B0DF;
    const MT_UPPER_MASK = 0x80000000;
    const MT_LOWER_MASK = 0x7FFFFFFF;

    class MersenneTwister {
        constructor(seedBigInt) {
            this.mt = new Uint32Array(MT_N);
            this.index = MT_N;
            this._seed(seedBigInt);
        }

        // Convert seed (BigInt) to 32-bit word array (little-endian),
        // then call init_by_array — matching Python's random.seed(int).
        _seed(seedBigInt) {
            if (seedBigInt < 0n) seedBigInt = -seedBigInt;

            const key = [];
            let a = seedBigInt;
            while (a > 0n) {
                key.push(Number(a & 0xFFFFFFFFn));
                a >>= 32n;
            }
            if (key.length === 0) key.push(0);

            this._init_by_array(key);
        }

        _init_genrand(s) {
            this.mt[0] = s >>> 0;
            for (let i = 1; i < MT_N; i++) {
                // Use Math.imul for 32-bit integer multiplication (wraps correctly)
                // Python: mt[i] = (1812433253 * (mt[i-1] ^ (mt[i-1] >> 30)) + i) & 0xFFFFFFFF
                const prev = this.mt[i - 1];
                const xored = prev ^ (prev >>> 30);
                this.mt[i] = (Math.imul(1812433253, xored) + i) >>> 0;
            }
            this.index = MT_N;
        }

        _init_by_array(initKey) {
            this._init_genrand(19650218);
            let i = 1, j = 0;
            const keyLen = initKey.length;
            const k = Math.max(MT_N, keyLen);

            for (let n = 0; n < k; n++) {
                // Python: mt[i] = (mt[i] ^ ((mt[i-1] ^ (mt[i-1] >> 30)) * 1664525)) + init_key[j] + j
                const prev = this.mt[i - 1];
                const xored = prev ^ (prev >>> 30);
                this.mt[i] = (
                    (this.mt[i] ^ Math.imul(1664525, xored))
                    + initKey[j] + j
                ) >>> 0;
                i++; j++;
                if (i >= MT_N) { this.mt[0] = this.mt[MT_N - 1]; i = 1; }
                if (j >= keyLen) j = 0;
            }

            for (let n = 0; n < MT_N - 1; n++) {
                // Python: mt[i] = (mt[i] ^ ((mt[i-1] ^ (mt[i-1] >> 30)) * 1566083941)) - i
                const prev = this.mt[i - 1];
                const xored = prev ^ (prev >>> 30);
                this.mt[i] = (
                    (this.mt[i] ^ Math.imul(1566083941, xored))
                    - i
                ) >>> 0;
                i++;
                if (i >= MT_N) { this.mt[0] = this.mt[MT_N - 1]; i = 1; }
            }

            this.mt[0] = 0x80000000;
            this.index = MT_N;
        }

        // Generate next 32-bit unsigned int
        _generate() {
            if (this.index >= MT_N) {
                this._generateBlock();
            }
            let y = this.mt[this.index++];
            y ^= (y >>> 11);
            y ^= (y << 7) & 0x9D2C5680;
            y ^= (y << 15) & 0xEFC60000;
            y ^= (y >>> 18);
            return y >>> 0;
        }

        _generateBlock() {
            for (let i = 0; i < MT_N; i++) {
                const y = (this.mt[i] & MT_UPPER_MASK) | (this.mt[(i + 1) % MT_N] & MT_LOWER_MASK);
                this.mt[i] = this.mt[(i + MT_M) % MT_N] ^ (y >>> 1);
                if (y & 1) this.mt[i] ^= MT_MATRIX_A;
            }
            this.index = 0;
        }

        // Returns k random bits as a regular number (k <= 32) or BigInt (k > 32)
        getrandbits(k) {
            if (k <= 0) return 0;
            if (k <= 32) {
                return this._generate() >>> (32 - k);
            }
            // For k > 32: multiple uint32s, little-endian word order
            const words = Math.ceil(k / 32);
            let result = 0n;
            let bitsLeft = k;
            for (let i = 0; i < words; i++) {
                let r = this._generate();
                const take = Math.min(32, bitsLeft);
                if (take < 32) r >>>= (32 - take);
                result |= BigInt(r) << BigInt(i * 32);
                bitsLeft -= 32;
            }
            return result;
        }

        // Python's _randbelow_with_getrandbits
        _randbelow(n) {
            if (n <= 0) throw new Error("n must be positive");
            const k = n.toString(2).length;  // bit_length
            let r = this.getrandbits(k);
            // For k > 32, r is BigInt; compare as BigInt
            const nBig = BigInt(n);
            while (BigInt(r) >= nBig) {
                r = this.getrandbits(k);
            }
            return Number(r);
        }

        // Fisher-Yates shuffle (matches Python's random.shuffle)
        shuffle(arr) {
            for (let i = arr.length - 1; i > 0; i--) {
                const j = this._randbelow(i + 1);
                const tmp = arr[i];
                arr[i] = arr[j];
                arr[j] = tmp;
            }
        }

        randrange(n) {
            return this._randbelow(n);
        }
    }


    // ======= SHA-256 =====================================================

    async function sha256Bytes(str) {
        const data = new TextEncoder().encode(str);
        const hashBuf = await crypto.subtle.digest('SHA-256', data);
        return new Uint8Array(hashBuf);
    }


    // ======= PROFILE DERIVATION ==========================================
    //
    // Must match generate_language_table.py derive_profile() exactly:
    //   1. canonical = '-'.join(triplet)  (e.g., "0-3-7")
    //   2. seed = int(SHA-256(canonical)[:8], big-endian) — 64-bit unsigned
    //   3. rng = MersenneTwister(seed)
    //   4. permutation = Fisher-Yates shuffle of [0..239]
    //   5. traversal = rng.randrange(7)
    //   6. chunk_size_idx = rng.randrange(7)
    //   7. chunk_internal = rng.randrange(7)
    //   8. position = rng.randrange(7)

    async function deriveProfile(tripletIndices) {
        // tripletIndices must be sorted (canonical)
        const canonical = tripletIndices.join('-');
        const hash = await sha256Bytes(canonical);

        // Seed = first 8 bytes, big-endian, 64-bit unsigned
        let seed = 0n;
        for (let i = 0; i < 8; i++) {
            seed = (seed << 8n) | BigInt(hash[i]);
        }

        const rng = new MersenneTwister(seed);

        // 1) Alphabet permutation via Fisher-Yates
        const permutation = Array.from({ length: 240 }, (_, i) => i);
        rng.shuffle(permutation);

        // 2-5) Dimension picks
        const traversal = rng.randrange(TRAVERSAL_COUNT);
        const chunkSizeIdx = rng.randrange(CHUNK_SIZE_COUNT);
        const chunkInternal = rng.randrange(CHUNK_INTERNAL_COUNT);
        const position = rng.randrange(POSITION_COUNT);

        return {
            permutation,
            traversal,
            chunkSize: CHUNK_SIZE_VALUES[chunkSizeIdx],
            chunkInternal,
            position,
        };
    }

    function getIdentityProfile() {
        return {
            permutation: Array.from({ length: 240 }, (_, i) => i),
            traversal: 0,
            chunkSize: 1,
            chunkInternal: 0,
            position: 0,
        };
    }


    // ======= TRANSFORM PERMUTATIONS ======================================
    //
    // These must match the Python functions exactly:
    //   traversal_permutation(variant, length)
    //   chunk_internal_permutation(variant, chunk_length)
    //   position_permutation(variant, length)

    function traversalPermutation(variant, length) {
        if (variant === 0) {
            return Array.from({ length }, (_, i) => i);
        } else if (variant === 1) {
            return Array.from({ length }, (_, i) => length - 1 - i);
        } else if (variant === 2) {
            const out = [];
            let left = 0, right = length - 1;
            while (left <= right) {
                out.push(left);
                if (left !== right) out.push(right);
                left++; right--;
            }
            return out;
        } else if (variant === 3) {
            const out = [];
            const mid = Math.floor(length / 2);
            if (length % 2 === 1) {
                out.push(mid);
                for (let d = 1; d <= mid; d++) {
                    out.push(mid - d);
                    if (mid + d < length) out.push(mid + d);
                }
            } else {
                for (let d = 0; d < length / 2; d++) {
                    out.push(mid - 1 - d);
                    out.push(mid + d);
                }
            }
            return out;
        } else if (variant === 4) {
            const out = [];
            for (let i = 1; i < length; i += 2) out.push(i);
            for (let i = 0; i < length; i += 2) out.push(i);
            return out;
        } else if (variant === 5) {
            const out = [];
            for (let i = 0; i < length; i += 2) out.push(i);
            for (let i = 1; i < length; i += 2) out.push(i);
            return out;
        } else if (variant === 6) {
            const out = [];
            for (let i = 0; i < length - 1; i += 2) {
                out.push(i + 1);
                out.push(i);
            }
            if (length % 2 === 1) out.push(length - 1);
            return out;
        }
        throw new Error("Invalid traversal variant: " + variant);
    }

    function chunkInternalPermutation(variant, L) {
        if (L <= 0) return [];
        if (variant === 0) {
            return Array.from({ length: L }, (_, i) => i);
        } else if (variant === 1) {
            return Array.from({ length: L }, (_, i) => L - 1 - i);
        } else if (variant === 2) {
            if (L <= 1) return Array.from({ length: L }, (_, i) => i);
            const out = [];
            for (let i = 1; i < L; i++) out.push(i);
            out.push(0);
            return out;
        } else if (variant === 3) {
            if (L <= 1) return Array.from({ length: L }, (_, i) => i);
            const out = [L - 1];
            for (let i = 0; i < L - 1; i++) out.push(i);
            return out;
        } else if (variant === 4) {
            const out = [];
            for (let i = 0; i < L - 1; i += 2) {
                out.push(i + 1);
                out.push(i);
            }
            if (L % 2 === 1) out.push(L - 1);
            return out;
        } else if (variant === 5) {
            const out = [];
            let left = 0, right = L - 1;
            while (left <= right) {
                if (left !== right) {
                    out.push(right);
                    out.push(left);
                } else {
                    out.push(left);
                }
                left++; right--;
            }
            return out;
        } else if (variant === 6) {
            return traversalPermutation(3, L);
        }
        throw new Error("Invalid chunk_internal variant: " + variant);
    }

    function positionPermutation(variant, length) {
        if (variant === 0) {
            return Array.from({ length }, (_, i) => i);
        } else if (variant === 1) {
            return Array.from({ length }, (_, i) => length - 1 - i);
        } else if (variant === 2) {
            const out = [];
            for (let r = 0; r < 3; r++) {
                for (let i = r; i < length; i += 3) out.push(i);
            }
            return out;
        } else if (variant === 3) {
            const out = [];
            for (let r = 0; r < 5; r++) {
                for (let i = r; i < length; i += 5) out.push(i);
            }
            return out;
        } else if (variant === 4) {
            const out = [];
            for (let i = 0; i < length; i += 2) out.push(i);
            for (let i = 1; i < length; i += 2) out.push(i);
            return out;
        } else if (variant === 5) {
            return traversalPermutation(6, length);
        } else if (variant === 6) {
            const out = [];
            for (let i = 0; i < length; i += 3) {
                const block = [];
                for (let j = i; j < Math.min(i + 3, length); j++) block.push(j);
                if (block.length === 3) {
                    out.push(block[2], block[0], block[1]);
                } else {
                    out.push(...block);
                }
            }
            return out;
        }
        throw new Error("Invalid position variant: " + variant);
    }


    // ======= PERMUTATION UTILITIES =======================================

    function invertPermutation(perm) {
        const inv = new Array(perm.length);
        for (let i = 0; i < perm.length; i++) {
            inv[perm[i]] = i;
        }
        return inv;
    }

    // out[i] = text[perm[i]]
    function applyPositionPermutation(text, perm) {
        let out = '';
        for (let i = 0; i < perm.length; i++) {
            out += text[perm[i]];
        }
        return out;
    }

    // Substitute each char: c -> ALPHABET[perm[ALPHABET_INDEX[c]]]
    function applyAlphabetPermutation(text, perm) {
        let out = '';
        for (const c of text) {
            const idx = ALPHABET_INDEX[c];
            out += ALPHABET[perm[idx]];
        }
        return out;
    }

    function chunkString(s, chunkSize) {
        if (chunkSize <= 1) return [s];
        const chunks = [];
        for (let i = 0; i < s.length; i += chunkSize) {
            chunks.push(s.substring(i, i + chunkSize));
        }
        return chunks;
    }


    // ======= URL UNQUOTE =================================================

    function unquote(str) {
        try {
            return decodeURIComponent(str);
        } catch (e) {
            // Fallback: manually decode %XX as UTF-8 bytes
            const bytes = [];
            let i = 0;
            while (i < str.length) {
                if (str[i] === '%' && i + 2 < str.length &&
                    /[0-9A-Fa-f]{2}/.test(str.substring(i + 1, i + 3))) {
                    bytes.push(parseInt(str.substring(i + 1, i + 3), 16));
                    i += 3;
                } else {
                    const encoded = new TextEncoder().encode(str[i]);
                    for (const b of encoded) bytes.push(b);
                    i++;
                }
            }
            return new TextDecoder('utf-8', { fatal: false }).decode(new Uint8Array(bytes));
        }
    }


    // ======= VS DECODE ===================================================

    function decodeVS(vsText) {
        let out = '';
        const upperExclusive = VS_BASE + 240;
        for (const c of vsText) {
            const code = c.codePointAt(0);
            if (code >= VS_BASE && code < upperExclusive) {
                out += ALPHABET[code - VS_BASE];
            } else {
                throw new Error(`Invalid variation selector: U+${code.toString(16).toUpperCase()}`);
            }
        }
        return out;
    }


    // ======= MARKER -> LANGUAGE KEY ======================================

    function markerCharsToKey(m1, m2, m3) {
        // Each m is a single codepoint string (from Array.from, so no surrogates).
        // Use codePointAt(0) for safe comparison.
        const chars = [m1, m2, m3];
        for (const c of chars) {
            const cp = c.codePointAt(0);
            if (LANG_MARKER_CP_TO_INDEX[cp] === undefined) {
                throw new Error(`Invalid language marker: U+${cp.toString(16).toUpperCase()}`);
            }
        }
        // All three same => identity
        if (m1 === m2 && m2 === m3) {
            return 'identity';
        }
        // Sort indices for canonical key
        const indices = chars.map(c => LANG_MARKER_CP_TO_INDEX[c.codePointAt(0)]).sort((a, b) => a - b);
        return indices.join('-');
    }


    // ======= MAIN DECODE =================================================

    async function decode(payload) {
        if (!payload || payload.length === 0) {
            throw new Error("Encoded payload is empty");
        }

        // Split by Unicode codepoints (not UTF-16 code units).
        // This is critical because some marker chars (e.g., U+E007F = Cancel Tag)
        // are above U+FFFF and are represented as surrogate pairs in JS strings.
        // Using payload[i] would return a surrogate half, not the full codepoint.
        const chars = Array.from(payload);

        if (chars.length < 4) {
            throw new Error("Payload too short: need at least flag + 3 markers");
        }

        // Read flag
        const flag = chars[0];
        if (!(flag in FLAG_TO_NORMALIZED)) {
            const cps = chars.slice(0, 8)
                .map(c => 'U+' + c.codePointAt(0).toString(16).toUpperCase().padStart(4, '0'))
                .join(' ');
            throw new Error(`Payload does not begin with a recognized flag. Leading: ${cps}`);
        }
        const normalized = FLAG_TO_NORMALIZED[flag];

        // Read language markers
        const m1 = chars[1];
        const m2 = chars[2];
        const m3 = chars[3];
        const languageKey = markerCharsToKey(m1, m2, m3);

        // Extract VS payload (everything after flag + 3 markers)
        const vsPayloadChars = chars.slice(4);
        const vsPayload = vsPayloadChars.join('');

        // Validate VS data
        if (vsPayloadChars.length > 0) {
            const upperExclusive = VS_BASE + 240;
            for (const c of vsPayloadChars) {
                const code = c.codePointAt(0);
                if (!(code >= VS_BASE && code < upperExclusive)) {
                    throw new Error(`Invalid VS char after language markers: U+${code.toString(16).toUpperCase()}`);
                }
            }
        }

        // Get profile
        let profile;
        if (languageKey === 'identity') {
            profile = getIdentityProfile();
        } else {
            const indices = languageKey.split('-').map(Number);
            profile = await deriveProfile(indices);
        }

        // Decode pipeline (reverse of encode):
        //   1. VS decode -> ALPHABET chars
        //   2. Undo position permutation
        //   3. Undo chunk-internal transform (per chunk)
        //   4. Undo alphabet permutation
        //   5. Undo traversal
        //   6. URL unquote if normalized

        let text = decodeVS(vsPayload);

        // Step 2: undo position
        const posPerm = positionPermutation(profile.position, text.length);
        text = applyPositionPermutation(text, invertPermutation(posPerm));

        // Step 3: undo chunk-internal
        const chunks = chunkString(text, profile.chunkSize);
        const originalChunks = [];
        for (const chunk of chunks) {
            const chunkPerm = chunkInternalPermutation(profile.chunkInternal, chunk.length);
            originalChunks.push(applyPositionPermutation(chunk, invertPermutation(chunkPerm)));
        }
        text = originalChunks.join('');

        // Step 4: undo alphabet permutation
        text = applyAlphabetPermutation(text, invertPermutation(profile.permutation));

        // Step 5: undo traversal
        const travPerm = traversalPermutation(profile.traversal, text.length);
        text = applyPositionPermutation(text, invertPermutation(travPerm));

        // Step 6: URL unquote if applicable
        if (normalized) {
            text = unquote(text);
        }

        return {
            text: text,
            language: languageKey,
            normalized: normalized,
        };
    }


    // ======= VALIDATION HELPERS ==========================================

    function isLikelyEncodedPayload(text) {
        if (!text || text.length < 4) return false;
        const flag = text[0];
        return flag === FLAG_RAW || flag === FLAG_URL;
    }

    function extractPayloads(text) {
        if (!text) return [];
        // Scan text for sequences that start with a flag char and contain
        // only flag/marker/VS chars. Returns array of found payloads.
        const results = [];
        const chars = Array.from(text);
        let i = 0;
        while (i < chars.length) {
            if (chars[i] === FLAG_RAW || chars[i] === FLAG_URL) {
                // Try to extract a payload starting here
                let j = i + 1;
                // Need at least 3 markers + some VS chars
                while (j < chars.length) {
                    const cp = chars[j].codePointAt(0);
                    const isMarker = LANG_MARKER_CP_TO_INDEX[cp] !== undefined;
                    const isVS = cp >= VS_BASE && cp < VS_BASE + 240;
                    if (!isMarker && !isVS) break;
                    j++;
                }
                if (j - i >= 4) {
                    results.push(chars.slice(i, j).join(''));
                }
                i = j;
            } else {
                i++;
            }
        }
        return results;
    }


    // ======= STRICT EXTRACTION ===========================================
    //
    // extractPayloadsStrict() matches the strict pattern:
    //   [flag][marker][marker][marker][1+ VS chars]
    //
    // Unlike extractPayloads() (which is greedy and absorbs any flag/marker/VS
    // chars it encounters), the strict extractor enforces positional rules:
    //   - Position 0: MUST be a flag char (U+034F or U+200C)
    //   - Positions 1, 2, 3: MUST be language marker chars
    //   - Position 4+: MUST be VS chars (U+E0100..U+E01EF)
    //   - Stops at the first char that violates the expected position
    //
    // This means stray marker chars between two payloads (or after a payload)
    // are NOT absorbed — each payload is cleanly separated.
    //
    // Returns array of {payload, startIndex, endIndex} where indices are
    // codepoint indices into the input text (via Array.from).

    function extractPayloadsStrict(text) {
        if (!text) return [];
        const results = [];
        const chars = Array.from(text);
        const n = chars.length;
        let i = 0;

        while (i < n) {
            // Step 1: Find a flag char
            if (chars[i] !== FLAG_RAW && chars[i] !== FLAG_URL) {
                i++;
                continue;
            }

            const startIndex = i;

            // Step 2: Need 3 markers at positions i+1, i+2, i+3
            if (i + 3 >= n) {
                // Not enough chars left for markers
                i++;
                continue;
            }

            let pos = i + 1;
            let markersOk = true;
            for (let k = 0; k < 3; k++) {
                const cp = chars[pos].codePointAt(0);
                if (LANG_MARKER_CP_TO_INDEX[cp] === undefined) {
                    markersOk = false;
                    break;
                }
                pos++;
            }

            if (!markersOk) {
                // Not a valid payload — flag was a false positive
                i++;
                continue;
            }

            // Step 3: Need at least 1 VS char at position pos
            if (pos >= n) {
                // Flag + 3 markers but no VS data — not a valid payload
                i++;
                continue;
            }

            const firstVsCp = chars[pos].codePointAt(0);
            if (!(firstVsCp >= VS_BASE && firstVsCp < VS_BASE + 240)) {
                // Position 4 is not a VS char — not a valid payload
                i++;
                continue;
            }

            // Step 4: Collect VS chars until we hit a non-VS char
            pos++;  // already validated the first VS char
            while (pos < n) {
                const cp = chars[pos].codePointAt(0);
                if (cp >= VS_BASE && cp < VS_BASE + 240) {
                    pos++;
                } else {
                    break;
                }
            }

            // We have a valid strict payload: [flag][3 markers][1+ VS chars]
            const payload = chars.slice(startIndex, pos).join('');
            results.push({
                payload: payload,
                startIndex: startIndex,
                endIndex: pos,  // exclusive
            });

            // Continue scanning after this payload
            i = pos;
        }

        return results;
    }


    // ======= PUBLIC API ==================================================

    return {
        decode,
        isLikelyEncodedPayload,
        extractPayloads,
        extractPayloadsStrict,
        ALPHABET,
        LANG_MARKERS,
        // Expose for testing:
        _MT: MersenneTwister,
        _deriveProfile: deriveProfile,
        _traversalPermutation: traversalPermutation,
        _chunkInternalPermutation: chunkInternalPermutation,
        _positionPermutation: positionPermutation,
        _decodeVS: decodeVS,
        _markerCharsToKey: markerCharsToKey,
    };
})();

// Make available globally
if (typeof window !== 'undefined') {
    window.VSEncoder = VSEncoder;
}
if (typeof globalThis !== 'undefined') {
    globalThis.VSEncoder = VSEncoder;
}
