// ======================================================================
// VSPayload — Normalizer for VSEncoder decoded output
// ======================================================================
//
// Takes the raw decoded text from VSEncoder.decode() and parses it into
// structured fields using a label + separator scheme.
//
// Format:
//   <data><label>¦<data><label>¦<data><label>¦
//
//   - Separator: ¦ (U+00A6 Broken Bar) — splits segments
//   - Label: trailing run of label chars at the end of each segment
//   - Label chars: ¨ º ¹ ² ³ ª *  (7 chars)
//   - Label order matters: º¹ ≠ ¹º (different labels)
//
// Single-char labels (7):
//   ¨  → url            (primary URL link)
//   º  → gl             (GL transform)
//   ¹  → profile        (Profile)
//   ª  → backup_url_1   (backup URL link 1)
//   *  → backup_url_2   (backup URL link 2)
//   ²  → (unassigned — register with VSPayload.registerLabel('²', 'your_field'))
//   ³  → (unassigned — register with VSPayload.registerLabel('³', 'your_field'))
//
// Multi-char labels (combinations):
//   º¹ → channel_id     (example — register your own)
//   *ª → backup_urls    (example)
//   Any permutation of the 7 label chars is a distinct label.
//   7 single + 42 two-char + 210 three-char + ... = 13,699 possible labels.
//
// Usage:
//   const decoded = await VSEncoder.decode(payload);
//   const fields = VSPayload.parseToMap(decoded.text);
//   console.log(fields.url);      // "https://..."
//   console.log(fields.profile);  // "some_profile_data"
//
//   // Or get raw segments:
//   const segments = VSPayload.parse(decoded.text);
//   // [{data: '61559332199788', label: 'º¹'}, {data: 'https://...', label: '*ª'}]
//
//   // Build (inverse of parse):
//   const text = VSPayload.build({url: 'https://...', profile: 'data'});
// ======================================================================

const VSPayload = (function () {
    'use strict';

    // ======= CONFIG =======================================================

    const SEPARATOR = '¦';  // U+00A6 Broken Bar

    // 7 label chars — "mini" chars that attach to the top or look like
    // superscript numbers. All are in the ALPHABET, so they encode 1:1.
    const LABEL_CHARS = ['¨', 'º', '¹', '²', '³', 'ª', '*'];
    const LABEL_CHAR_SET = new Set(LABEL_CHARS);

    // Default label → field name mapping.
    // Single-char labels are pre-registered. Multi-char labels can be
    // added via registerLabel().
    const LABEL_MAP = {
        '¨':  'url',           // Primary URL link
        'º':  'gl',            // GL transform
        '¹':  'profile',      // Profile
        'ª':  'backup_url_1', // Backup URL link 1
        '*':  'backup_url_2', // Backup URL link 2
        '²':  null,           // TBD — register with registerLabel('²', 'field')
        '³':  null,           // TBD — register with registerLabel('³', 'field')
    };


    // ======= HELPERS ======================================================

    function isLabelChar(c) {
        return LABEL_CHAR_SET.has(c);
    }

    function isValidLabel(label) {
        if (label === '') return true;  // empty label is valid (unlabeled data)
        for (const c of label) {
            if (!LABEL_CHAR_SET.has(c)) return false;
        }
        return true;
    }

    /**
     * Extract the trailing label from a segment.
     * The label is the longest trailing run of label chars.
     *
     * Example:
     *   '61559332199788º¹' → {data: '61559332199788', label: 'º¹'}
     *   'https://example.com*ª' → {data: 'https://example.com', label: '*ª'}
     *   'plain data' → {data: 'plain data', label: ''}
     *
     * Note: if data naturally ends with a label char (e.g., a URL ending
     * with '*'), it will be interpreted as part of the label. To avoid
     * this, add a non-label char (like a space) after the data.
     */
    function extractLabel(segment) {
        const chars = Array.from(segment);
        let i = chars.length - 1;
        const labelParts = [];
        while (i >= 0 && LABEL_CHAR_SET.has(chars[i])) {
            labelParts.unshift(chars[i]);  // prepend to maintain original order
            i--;
        }
        const label = labelParts.join('');
        const data = chars.slice(0, i + 1).join('');
        return { data, label };
    }


    // ======= PARSING ======================================================

    /**
     * Parse decoded text into an array of {data, label} segments.
     *
     * Example:
     *   '61559332199788º¹¦https://example.com*ª¦'
     *   → [
     *       {data: '61559332199788', label: 'º¹'},
     *       {data: 'https://example.com', label: '*ª'}
     *     ]
     *
     * Trailing separator is handled (no empty segment at the end).
     * Empty input returns [].
     */
    function parse(text) {
        if (!text) return [];

        const segments = text.split(SEPARATOR);

        // Remove trailing empty segment (from trailing separator)
        if (segments.length > 0 && segments[segments.length - 1] === '') {
            segments.pop();
        }

        return segments.map(seg => extractLabel(seg));
    }

    /**
     * Get the field name for a label, using LABEL_MAP.
     * Returns 'unlabeled' for empty labels.
     * Returns 'label_<label>' for unregistered multi-char labels.
     */
    function getFieldName(label) {
        if (label === '') return 'unlabeled';
        const name = LABEL_MAP[label];
        if (name !== undefined && name !== null) return name;
        return 'label_' + label;
    }

    /**
     * Parse decoded text into a {fieldName: data} map.
     * If two segments have the same label, the LAST one wins.
     *
     * Example:
     *   'https://example.com¨¦profile_data¹¦'
     *   → {url: 'https://example.com', profile: 'profile_data'}
     *
     * For multi-valued fields (same label appears multiple times),
     * use parseToMultiMap() instead.
     */
    function parseToMap(text) {
        const segments = parse(text);
        const result = {};
        for (const { data, label } of segments) {
            const fieldName = getFieldName(label);
            result[fieldName] = data;
        }
        return result;
    }

    /**
     * Parse decoded text into a {fieldName: [data, ...]} map.
     * Each field value is an array, supporting duplicate labels.
     *
     * Example:
     *   'url1¨¦url2¨¦'
     *   → {url: ['url1', 'url2']}
     */
    function parseToMultiMap(text) {
        const segments = parse(text);
        const result = {};
        for (const { data, label } of segments) {
            const fieldName = getFieldName(label);
            if (!result[fieldName]) {
                result[fieldName] = [];
            }
            result[fieldName].push(data);
        }
        return result;
    }


    // ======= BUILDING (inverse of parse) ==================================

    /**
     * Build a formatted string from a {fieldName: data} map.
     * This is the inverse of parseToMap().
     *
     * Example:
     *   build({url: 'https://example.com', profile: 'data'})
     *   → 'https://example.com¨¦data¹¦'
     *
     * Throws if a field name has no registered label.
     */
    function build(fields) {
        // Build reverse map: fieldName → label
        const reverseMap = {};
        for (const [label, field] of Object.entries(LABEL_MAP)) {
            if (field) reverseMap[field] = label;
        }

        const segments = [];
        for (const [field, data] of Object.entries(fields)) {
            const label = reverseMap[field];
            if (!label) {
                throw new Error(`No label registered for field: ${field}. ` +
                    `Register with VSPayload.registerLabel(label, '${field}').`);
            }
            segments.push(data + label);
        }
        return segments.join(SEPARATOR) + (segments.length > 0 ? SEPARATOR : '');
    }

    /**
     * Build a formatted string from an array of {data, label} segments.
     * This is the inverse of parse().
     *
     * Example:
     *   buildSegments([
     *     {data: '61559332199788', label: 'º¹'},
     *     {data: 'https://example.com', label: '*ª'}
     *   ])
     *   → '61559332199788º¹¦https://example.com*ª¦'
     */
    function buildSegments(segments) {
        return segments.map(s => s.data + s.label).join(SEPARATOR) +
               (segments.length > 0 ? SEPARATOR : '');
    }


    // ======= LABEL REGISTRATION ===========================================

    /**
     * Register a label → field name mapping.
     * Works for both single-char and multi-char labels.
     *
     * Examples:
     *   registerLabel('º¹', 'channel_id');
     *   registerLabel('*ª', 'backup_urls');
     *   registerLabel('²', 'metadata');
     *
     * After registration, parseToMap() will use the field name for that label.
     */
    function registerLabel(label, fieldName) {
        if (!isValidLabel(label)) {
            throw new Error(`Invalid label: ${JSON.stringify(label)}. ` +
                `Label chars must be one of: ${LABEL_CHARS.join(' ')}`);
        }
        LABEL_MAP[label] = fieldName;
    }

    /**
     * Register multiple labels at once.
     * Example:
     *   registerLabels({'º¹': 'channel_id', '*ª': 'backup_urls'});
     */
    function registerLabels(mapping) {
        for (const [label, field] of Object.entries(mapping)) {
            registerLabel(label, field);
        }
    }

    /**
     * Get all registered labels as {label: fieldName}.
     */
    function getRegisteredLabels() {
        const result = {};
        for (const [label, field] of Object.entries(LABEL_MAP)) {
            if (field !== null) result[label] = field;
        }
        return result;
    }


    // ======= VALIDATION ===================================================

    /**
     * Validate that a text string is well-formed.
     * Returns {valid: true} or {valid: false, error: 'message'}.
     */
    function validate(text) {
        if (!text) return { valid: true };

        const segments = text.split(SEPARATOR);

        // Remove trailing empty
        if (segments.length > 0 && segments[segments.length - 1] === '') {
            segments.pop();
        }

        for (let i = 0; i < segments.length; i++) {
            const seg = segments[i];
            const { data, label } = extractLabel(seg);

            if (!isValidLabel(label)) {
                return { valid: false, error: `Segment ${i} has invalid label chars: ${JSON.stringify(label)}` };
            }

            if (data === '' && label === '') {
                return { valid: false, error: `Segment ${i} is empty` };
            }
        }

        return { valid: true };
    }


    // ======= PUBLIC API ==================================================

    return {
        // Constants
        SEPARATOR,
        LABEL_CHARS,

        // Parsing
        parse,
        parseToMap,
        parseToMultiMap,

        // Building
        build,
        buildSegments,

        // Label management
        registerLabel,
        registerLabels,
        getFieldName,
        getRegisteredLabels,

        // Utilities
        isLabelChar,
        isValidLabel,
        extractLabel,
        validate,
    };
})();

// Make available globally
if (typeof window !== 'undefined') {
    window.VSPayload = VSPayload;
}
if (typeof globalThis !== 'undefined') {
    globalThis.VSPayload = VSPayload;
}
