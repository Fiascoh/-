# ============================================================
# CELL 6: Process Audio Files
# ============================================================
#  Reads filenames from Encor/filenames.txt
#  Processes each audio file from Echo/
#  Outputs three files per audio to Profile_Outputs/
# ============================================================

# Read filenames to process
with open(FILNAMES_FILE, 'r') as f:
    filenames = [line.strip() for line in f if line.strip() and not line.startswith('#')]

if not filenames:
    print('⚠ No filenames in filenames.txt')
    print(f'  Add filenames to: {FILNAMES_FILE}')
    print(f'  Audio files should be in: {ECHO}')
    # Auto-discover files in Echo/
    import glob
    auto_files = glob.glob(os.path.join(ECHO, '*'))
    if auto_files:
        filenames = [os.path.basename(f) for f in auto_files if os.path.isfile(f)]
        print(f'  Auto-discovered {len(filenames)} file(s) in Echo/')
    else:
        print('  No files found in Echo/ either.')

print(f'\n📋 Files to process: {len(filenames)}')
for i, name in enumerate(filenames):
    print(f'  {i+1}. {name}')
print()

# Process each file
for idx, filename in enumerate(filenames):
    audio_path = os.path.join(ECHO, filename)
    base_name = os.path.splitext(filename)[0]

    print(f'─────────────────────────────────────────────')
    print(f'[{idx+1}/{len(filenames)}] {filename}')

    if not os.path.exists(audio_path):
        print(f'  ✗ File not found: {audio_path}')
        continue

    try:
        t0 = time.time()

        # Generate profiles
        profile_data = generate_profiles(audio_path)

        elapsed = time.time() - t0
        print(f'  Processed in {elapsed:.1f}s')

        # Output 1: Pretty JSON (human-readable)
        pretty_path = os.path.join(OUTPUTS, f'{base_name}.pretty.json')
        with open(pretty_path, 'w') as f:
            json.dump(profile_data, f, indent=2)
        pretty_size = os.path.getsize(pretty_path)

        # Output 2: Compact JSON (minified)
        compact_path = os.path.join(OUTPUTS, f'{base_name}.compact.json')
        with open(compact_path, 'w') as f:
            json.dump(profile_data, f, separators=(',', ':'))
        compact_size = os.path.getsize(compact_path)

        # Output 3: PBF (Phantom Binary Format — ultra-compressed)
        pbf_str = encode_pbf(profile_data)
        pbf_path = os.path.join(OUTPUTS, f'{base_name}.pbf')
        with open(pbf_path, 'w') as f:
            f.write(pbf_str)
        pbf_size = os.path.getsize(pbf_path)

        # Verify PBF round-trip
        decoded = decode_pbf(pbf_str)
        assert decoded['etag'] == profile_data['etag']
        assert decoded['profiles'][3]['character']['loGainDb'] == profile_data['profiles'][3]['character']['loGainDb']

        # Size comparison
        reduction = (1 - pbf_size / pretty_size) * 100
        print(f'  ✓ Outputs:')
        print(f'    pretty.json  {pretty_size:>6} bytes')
        print(f'    compact.json {compact_size:>6} bytes')
        print(f'    .pbf         {pbf_size:>6} bytes  ({reduction:.0f}% smaller than pretty)')
        print(f'  ✓ PBF round-trip verified')
        print(f'  ETag: {profile_data["etag"][:16]}...')

    except Exception as e:
        print(f'  ✗ Error: {e}')
        import traceback
        traceback.print_exc()

print(f'\n─────────────────────────────────────────────')
print(f'✓ Done. Outputs in: {OUTPUTS}')
