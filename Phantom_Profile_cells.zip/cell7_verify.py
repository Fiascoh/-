# ============================================================
# CELL 7: Verify & Preview Outputs
# ============================================================
#  Lists all generated files and shows a sample PBF
# ============================================================

import glob

output_files = sorted(glob.glob(os.path.join(OUTPUTS, '*')))
print(f'📁 Profile outputs: {len(output_files)} files')
print(f'   Location: {OUTPUTS}\n')

for f in output_files:
    size = os.path.getsize(f)
    name = os.path.basename(f)
    print(f'   {name:<40} {size:>6} bytes')

# Show a sample PBF
pbf_files = [f for f in output_files if f.endswith('.pbf')]
if pbf_files:
    print(f'\n📄 Sample PBF ({os.path.basename(pbf_files[0])}):')
    with open(pbf_files[0], 'r') as f:
        content = f.read()
    print(f'   {content[:200]}...')
    print(f'   Total: {len(content)} bytes')

    # Decode and verify
    decoded = decode_pbf(content)
    print(f'\n🔍 Decoded verification:')
    print(f'   ETag: {decoded["etag"][:16]}...')
    print(f'   Duration: {decoded["duration"]}s')
    print(f'   Tier 3 character loGainDb: {decoded["profiles"][3]["character"]["loGainDb"]}')
    print(f'   Tier 3 character harmonicDrive: {decoded["profiles"][3]["character"]["harmonicDrive"]}')

# Show pretty JSON sample
pretty_files = [f for f in output_files if f.endswith('.pretty.json')]
if pretty_files:
    print(f'\n📄 Sample pretty JSON (first 500 chars):')
    with open(pretty_files[0], 'r') as f:
        content = f.read()
    print(content[:500])
    print(f'   ... ({len(content)} bytes total)')
