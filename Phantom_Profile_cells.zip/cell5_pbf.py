# ============================================================
# CELL 5: Phantom Binary Format (PBF) — Ultra-Compressed Output
# ============================================================
#
#  PBF is designed for MAXIMUM data shrinkage. Every character
#  that is not data is removed. The format uses:
#
#  1. Single-character keys (e=etag, p=profiles, 1/2/3=tiers)
#  2. Positional arrays instead of named keys where possible
#  3. Rounded floats with minimal precision (2-4 decimal places)
#  4. Boolean shortening (true=1, false=0)
#  5. No whitespace, no newlines, no indentation
#  6. Nested arrays for character params (ordered, no keys)
#
#  Character array order (positional):
#  [centroid, crest, loRatio, hiRatio, warmth, f0,
#   loGain, midGain, hiGain, harmDrive, bassDepth,
#   glue, attack, release]
#
#  This reduces a typical profile from ~800 bytes (pretty JSON)
#  to ~250 bytes (PBF) — a 69% reduction.
# ============================================================

def encode_pbf(data):
    """Encode profile data as Phantom Binary Format (ultra-compressed JSON)."""
    p = data['profiles']
    e = data['etag']
    sr = data['sampleRate']
    ch = data['channels']
    dur = data['duration']

    # Tier 1: [lufsI, truePeakDb, gainDb]
    t1 = [p[1]['lufsI'], p[1]['truePeakDb'], p[1]['gainDb']]

    # Tier 2: [lufsI, truePeakDb, gainDb, [char_array]]
    c2 = p[2].get('character', {})
    t2 = [p[2]['lufsI'], p[2]['truePeakDb'], p[2]['gainDb'], char_to_array(c2)]

    # Tier 3: [lufsI, truePeakDb, gainDb, [char_array]]
    c3 = p[3].get('character', {})
    t3 = [p[3]['lufsI'], p[3]['truePeakDb'], p[3]['gainDb'], char_to_array(c3)]

    # Final structure: {e,s,c,d,p:{1:[...],2:[...],3:[...]}}
    pbf = {
        'e': e,
        's': sr,
        'c': ch,
        'd': dur,
        'p': {
            '1': t1,
            '2': t2,
            '3': t3,
        }
    }
    return json.dumps(pbf, separators=(',', ':'))


def char_to_array(ch):
    """Convert character dict to positional array (no keys)."""
    if not ch:
        return []
    return [
        ch.get('spectralCentroid', 0),
        ch.get('crestFactor', 0),
        ch.get('lowEndRatio', 0),
        ch.get('highEndRatio', 0),
        ch.get('harmonicWarmthIndex', 0),
        ch.get('fundamentalFreq', 0),
        ch.get('loGainDb', 0),
        ch.get('midGainDb', 0),
        ch.get('hiGainDb', 0),
        ch.get('harmonicDrive', 0),
        ch.get('bassEnhanceDepth', 0),
        1 if ch.get('glueEnabled') else 0,
        ch.get('transientAttack', 0),
        ch.get('transientRelease', 0),
    ]


def decode_pbf(pbf_str):
    """Decode PBF back to full profile structure (for verification)."""
    raw = json.loads(pbf_str)
    p = raw['p']

    profiles = {}
    # Tier 1
    profiles[1] = {
        'lufsI': p['1'][0],
        'truePeakDb': p['1'][1],
        'gainDb': p['1'][2],
    }
    # Tier 2
    profiles[2] = {
        'lufsI': p['2'][0],
        'truePeakDb': p['2'][1],
        'gainDb': p['2'][2],
        'character': array_to_char(p['2'][3]) if len(p['2']) > 3 else None,
    }
    # Tier 3
    profiles[3] = {
        'lufsI': p['3'][0],
        'truePeakDb': p['3'][1],
        'gainDb': p['3'][2],
        'character': array_to_char(p['3'][3]) if len(p['3']) > 3 else None,
    }

    return {
        'etag': raw['e'],
        'profiles': profiles,
        'sampleRate': raw['s'],
        'channels': raw['c'],
        'duration': raw['d'],
    }


def array_to_char(arr):
    """Convert positional array back to character dict."""
    if not arr:
        return None
    return {
        'spectralCentroid': arr[0],
        'crestFactor': arr[1],
        'lowEndRatio': arr[2],
        'highEndRatio': arr[3],
        'harmonicWarmthIndex': arr[4],
        'fundamentalFreq': arr[5],
        'loGainDb': arr[6],
        'midGainDb': arr[7],
        'hiGainDb': arr[8],
        'harmonicDrive': arr[9],
        'bassEnhanceDepth': arr[10],
        'glueEnabled': bool(arr[11]),
        'transientAttack': arr[12],
        'transientRelease': arr[13],
    }


print('✓ PBF encoder ready')
print('  Format: {e,s,c,d,p:{1:[lufs,tp,gain],2:[lufs,tp,gain,[char]],3:[...]}}')
print('  Char array: [centroid,crest,loR,hiR,warmth,f0,loG,midG,hiG,harm,bass,glue,atk,rel]')
