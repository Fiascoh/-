# ============================================================
# CELL 1: Mount Drive & Create Folder Structure
# ============================================================

import os
import json
from pathlib import Path

# ── Base path ──────────────────────────────────────────────
BASE = '/content/drive/MyDrive/L●○P/HYDRA'
MAIN = os.path.join(BASE, 'Phantom_Profile')
ECHO = os.path.join(MAIN, 'Echo')
ENCOR = os.path.join(MAIN, 'Encor')
OUTPUTS = os.path.join(ENCOR, 'Profile_Outputs')
FILNAMES_FILE = os.path.join(ENCOR, 'filenames.txt')

# ── Mount Google Drive ─────────────────────────────────────
try:
    from google.colab import drive
    drive.mount('/content/drive', force_remount=True)
    print('✓ Drive mounted')
except ImportError:
    print('⚠ Not in Colab — using local filesystem')
    # Adjust paths for local PC
    BASE = os.path.expanduser('~/HYDRA')
    MAIN = os.path.join(BASE, 'Phantom_Profile')
    ECHO = os.path.join(MAIN, 'Echo')
    ENCOR = os.path.join(MAIN, 'Encor')
    OUTPUTS = os.path.join(ENCOR, 'Profile_Outputs')
    FILNAMES_FILE = os.path.join(ENCOR, 'filenames.txt')

# ── Create all folders if they don't exist ──────────────────
for folder in [BASE, MAIN, ECHO, ENCOR, OUTPUTS]:
    os.makedirs(folder, exist_ok=True)
    print(f'✓ {folder}')

# ── Create filenames.txt if it doesn't exist ────────────────
if not os.path.exists(FILNAMES_FILE):
    with open(FILNAMES_FILE, 'w') as f:
        f.write('# Add one audio filename per line (files must be in Echo/ folder)\n')
        f.write('# Example: my_song.mp3\n')
    print(f'✓ Created {FILNAMES_FILE} (add filenames to process)')
else:
    print(f'✓ {FILNAMES_FILE} exists')

print(f'\n📁 Structure ready at: {MAIN}')
