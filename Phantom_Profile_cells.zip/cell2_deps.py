# ============================================================
# CELL 2: Install Dependencies & Import
# ============================================================

import subprocess, sys

def pip_install(pkg):
    subprocess.check_call([sys.executable, '-m', 'pip', 'install', pkg, '-q'])

# Install required packages
try:
    import soundfile as sf
except ImportError:
    pip_install('soundfile')
    import soundfile as sf

try:
    import numpy as np
except ImportError:
    pip_install('numpy')
    import numpy as np

try:
    import scipy
except ImportError:
    pip_install('scipy')
    import scipy
from scipy import signal as scipy_signal

import struct
import base64
import hashlib
import math
import time

print('✓ All dependencies installed')
