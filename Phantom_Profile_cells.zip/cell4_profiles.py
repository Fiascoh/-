# ============================================================
# CELL 4: Profile Generation
# ============================================================
#  Generates three profiles per audio file:
#    Tier 1: Loudness only (LUFS + true-peak + gain)
#    Tier 2: Light enhancement (reduced character params)
#    Tier 3: Full enhancement (all character params)
# ============================================================

TARGET_LUFS = -14.0
LUFS_HEADROOM_DB = 0.3
TRUE_PEAK_CEIL_DB = -1.0

# Tier-specific analysis parameters
TIER_PARAMS = {
    1: {'lufs_max_sec': 0,   'char_max_sec': 0,  'fft_size': 1024, 'num_windows': 0, 'fir_taps': 8},
    2: {'lufs_max_sec': 20,  'char_max_sec': 15, 'fft_size': 2048, 'num_windows': 4, 'fir_taps': 16},
    3: {'lufs_max_sec': 45,  'char_max_sec': 30, 'fft_size': 4096, 'num_windows': 8, 'fir_taps': 32},
}

def generate_profiles(file_path):
    """Generate all three tier profiles for an audio file."""
    # Load audio
    audio_data, sample_rate = sf.read(file_path, dtype='float64')
    if audio_data.ndim == 1:
        audio_data = audio_data.reshape(1, -1)
    channels = [audio_data[c] for c in range(audio_data.shape[0])]
    n_ch = len(channels)
    duration = len(channels[0]) / sample_rate

    print(f'  Loaded: {duration:.1f}s, {sample_rate}Hz, {n_ch}ch')

    # Compute LUFS + true-peak (once, used by all tiers)
    lufs_fast = fast_estimate_lufs(channels, sample_rate, duration)
    lufs_i, true_peak_db = compute_lufs(channels, sample_rate, duration,
                                          analysis_max_sec=TIER_PARAMS[3]['lufs_max_sec'])
    # Compute gain
    gain_db = (TARGET_LUFS - lufs_i) + LUFS_HEADROOM_DB
    proj_peak = true_peak_db + gain_db
    if proj_peak > TRUE_PEAK_CEIL_DB:
        gain_db -= (proj_peak - TRUE_PEAK_CEIL_DB)

    print(f'  LUFS={lufs_i:.1f}  truePeak={true_peak_db:.1f}dBTP  gain={gain_db:.2f}dB')

    profiles = {}

    # Tier 1: Loudness only
    profiles[1] = {
        'lufsI': round(lufs_i, 1),
        'truePeakDb': round(true_peak_db, 1),
        'gainDb': round(gain_db, 2),
    }

    # Tier 2: Light character
    char2 = profile_character(
        channels, sample_rate, duration,
        char_max_sec=TIER_PARAMS[2]['char_max_sec'],
        num_windows=TIER_PARAMS[2]['num_windows'],
        fft_size=TIER_PARAMS[2]['fft_size'],
        f0_min=80, f0_max=400
    )
    profiles[2] = {
        'lufsI': round(lufs_i, 1),
        'truePeakDb': round(true_peak_db, 1),
        'gainDb': round(gain_db, 2),
        'character': char2,
    }

    # Tier 3: Full character
    char3 = profile_character(
        channels, sample_rate, duration,
        char_max_sec=TIER_PARAMS[3]['char_max_sec'],
        num_windows=TIER_PARAMS[3]['num_windows'],
        fft_size=TIER_PARAMS[3]['fft_size'],
        f0_min=50, f0_max=1000
    )
    profiles[3] = {
        'lufsI': round(lufs_i, 1),
        'truePeakDb': round(true_peak_db, 1),
        'gainDb': round(gain_db, 2),
        'character': char3,
    }

    # ETag
    etag = compute_etag(file_path)

    result = {
        'etag': etag,
        'profiles': profiles,
        'sampleRate': sample_rate,
        'channels': n_ch,
        'duration': round(duration, 1),
        'lufsFast': round(lufs_fast, 1),
    }

    return result

print('✓ Profile generator ready')
