# ============================================================
# CELL 3: DSP Engine — BS.1770-4 LUFS, True-Peak, Character
# ============================================================
#  This module replicates the exact algorithms used by the
#  Phantom-Audio userscript, ensuring profile compatibility.
# ============================================================

def kweight_coeffs(sample_rate):
    """BS.1770-4 K-weighting filter coefficients."""
    # Stage 1 — high shelf
    f0 = 1681.974450955533
    G = 3.999843853973347
    Q1 = 0.7071752369554196
    K1 = math.tan(math.pi * f0 / sample_rate)
    Vh = 10 ** (G / 20)
    Vb = Vh ** 0.49966677415454674
    d0 = 1 + K1 / Q1 + K1 * K1
    hs = {
        'b0': (Vh + Vb * K1 / Q1 + K1 * K1) / d0,
        'b1': 2 * (K1 * K1 - Vh) / d0,
        'b2': (Vh - Vb * K1 / Q1 + K1 * K1) / d0,
        'a1': 2 * (K1 * K1 - 1) / d0,
        'a2': (1 - K1 / Q1 + K1 * K1) / d0,
    }
    # Stage 2 — high pass
    f1 = 38.13547087602444
    Q2 = 0.5003270373238773
    K2 = math.tan(math.pi * f1 / sample_rate)
    d2 = 1 + K2 / Q2 + K2 * K2
    hp = {
        'b0': 1 / d2,
        'b1': -2 / d2,
        'b2': 1 / d2,
        'a1': 2 * (K2 * K2 - 1) / d2,
        'a2': (1 - K2 / Q2 + K2 * K2) / d2,
    }
    return [hs, hp]


def apply_biquad_cascade(samples, bq_coeffs):
    """Apply cascaded biquad filters in-place."""
    for bq in bq_coeffs:
        b0, b1, b2 = bq['b0'], bq['b1'], bq['b2']
        a1, a2 = bq['a1'], bq['a2']
        x1 = x2 = y1 = y2 = 0.0
        for i in range(len(samples)):
            x = samples[i]
            y = b0 * x + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2
            x2 = x1; x1 = x; y2 = y1; y1 = y
            samples[i] = y
    return samples


def compute_lufs(channels, sample_rate, duration, analysis_max_sec=45):
    """Full BS.1770-4 integrated loudness + true-peak."""
    n_ch = len(channels)
    offset_sec = max(0, duration * 0.25)
    max_sec = min(analysis_max_sec, duration - offset_sec)
    start_smp = int(offset_sec * sample_rate)
    max_smp = min(int(max_sec * sample_rate), len(channels[0]) - start_smp)

    bq = kweight_coeffs(sample_rate)
    W = [1.41 if c in (4, 5) else 1.0 for c in range(n_ch)]

    kw = []
    true_peak_lin = 0.0
    for c in range(n_ch):
        d = channels[c][start_smp:start_smp + max_smp].copy()
        # True-peak: 4x oversample with 32-tap sinc FIR
        tp = true_peak_channel(d, fir_taps=32)
        if tp > true_peak_lin:
            true_peak_lin = tp
        apply_biquad_cascade(d, bq)
        kw.append(d)

    block_samp = int(0.4 * sample_rate)
    hop_samp = int(0.1 * sample_rate)
    total_samp = len(kw[0])
    blocks = []
    for s in range(0, total_samp - block_samp + 1, hop_samp):
        ms = 0.0
        for c in range(n_ch):
            d = kw[c][s:s + block_samp]
            ms += W[c] * np.dot(d, d) / block_samp
        blocks.append(ms)

    if not blocks:
        return -70.0, 20 * math.log10(max(true_peak_lin, 1e-9))

    to_lufs = lambda ms: -0.691 + 10 * math.log10(max(ms, 1e-12))
    abs_gate = 10 ** ((-70 + 0.691) / 10)
    g1 = [b for b in blocks if b >= abs_gate]
    if not g1:
        return -70.0, 20 * math.log10(max(true_peak_lin, 1e-9))
    mean1 = sum(g1) / len(g1)
    rel_gate = mean1 * 10 ** (-10 / 10)
    g2 = [b for b in g1 if b >= rel_gate]
    mean2 = sum(g2 if g2 else g1) / (len(g2) if g2 else len(g1))
    return to_lufs(mean2), 20 * math.log10(max(true_peak_lin, 1e-9))


def true_peak_channel(data, fir_taps=32, oversample=4):
    """4x oversampled true-peak measurement."""
    N = oversample
    up = np.zeros(len(data) * N)
    up[::N] = data * N

    fc = 0.5 / N
    taps = fir_taps
    h = np.zeros(taps)
    for k in range(taps):
        n = k - (taps - 1) / 2
        sinc = 1.0 if n == 0 else math.sin(math.pi * 2 * fc * n) / (math.pi * 2 * fc * n)
        win = 0.42 - 0.5 * math.cos(2 * math.pi * k / (taps - 1)) + 0.08 * math.cos(4 * math.pi * k / (taps - 1))
        h[k] = sinc * win
    h /= h.sum()  # normalize

    out = np.convolve(up, h, mode='full')[:len(up)]
    return float(np.max(np.abs(out)))


def fast_estimate_lufs(channels, sample_rate, duration, fast_sample_sec=6):
    """Quick LUFS estimate from a short window."""
    n_ch = len(channels)
    offset_sec = min(max(0.30 * duration, 1.0), max(duration - fast_sample_sec - 1, 1.0))
    start_smp = int(offset_sec * sample_rate)
    max_smp = min(int(fast_sample_sec * sample_rate), len(channels[0]) - start_smp)
    if max_smp < sample_rate:
        return -70.0

    bq = kweight_coeffs(sample_rate)
    W = [1.41 if c in (4, 5) else 1.0 for c in range(n_ch)]
    total_ms = 0.0
    for c in range(n_ch):
        d = channels[c][start_smp:start_smp + max_smp].copy()
        apply_biquad_cascade(d, bq)
        total_ms += W[c] * np.dot(d, d) / len(d)
    if total_ms < 1e-12:
        return -70.0
    return -0.691 + 10 * math.log10(total_ms / n_ch)


def profile_character(channels, sample_rate, duration, char_max_sec=30,
                       num_windows=8, fft_size=4096,
                       f0_min=50, f0_max=1000):
    """Full psychoacoustic character profile."""
    n_ch = len(channels)
    max_smp = min(len(channels[0]), int(char_max_sec * sample_rate))

    # Mix to mono
    mono = np.zeros(max_smp, dtype=np.float64)
    for c in range(n_ch):
        mono += channels[c][:max_smp] / n_ch

    # Crest factor
    peak = float(np.max(np.abs(mono)))
    rms_val = float(np.sqrt(np.mean(mono ** 2)))
    crest_db = 20 * math.log10(peak / rms_val) if rms_val > 0 else 20.0

    # Average spectrum via FFT
    win_len = fft_size * 2
    hann = np.hanning(win_len)
    avg_mag = np.zeros(fft_size // 2)
    wins_processed = 0

    for w in range(num_windows):
        offset = int((len(mono) - win_len) * (w / max(num_windows - 1, 1)))
        if offset < 0 or offset + win_len > len(mono):
            continue
        segment = mono[offset:offset + win_len] * hann
        spectrum = np.fft.rfft(segment)
        mag = np.abs(spectrum[:fft_size // 2])
        avg_mag += mag
        wins_processed += 1

    if wins_processed > 0:
        avg_mag /= wins_processed

    # Band energy
    bin_hz = sample_rate / fft_size
    lo_bin = int(250 / bin_hz)
    m_bin = int(3500 / bin_hz)
    lo_e = float(np.sum(avg_mag[:lo_bin] ** 2))
    mid_e = float(np.sum(avg_mag[lo_bin:m_bin] ** 2))
    hi_e = float(np.sum(avg_mag[m_bin:] ** 2))
    total_e = lo_e + mid_e + hi_e
    low_end_ratio = lo_e / total_e if total_e > 0 else 0.33
    high_end_ratio = hi_e / total_e if total_e > 0 else 0.33

    # Spectral centroid
    freqs = np.arange(len(avg_mag)) * bin_hz
    centroid = float(np.sum(freqs * avg_mag) / max(np.sum(avg_mag), 1e-9))

    # f0 detection via autocorrelation
    f0 = detect_f0(mono, sample_rate, f0_min, f0_max)

    # Harmonic warmth
    odd_e = even_e = 0.0
    if f0 > 0:
        for h in range(2, 13):
            freq = f0 * h
            bin_idx = int(freq / bin_hz)
            if bin_idx >= len(avg_mag):
                break
            w2 = 2
            lo = max(0, bin_idx - w2)
            hi = min(len(avg_mag) - 1, bin_idx + w2)
            e = float(np.sum(avg_mag[lo:hi+1] ** 2))
            if h % 2 == 1:
                odd_e += e
            else:
                even_e += e
    harmonic_warmth = odd_e / (odd_e + even_e) if (odd_e + even_e) > 0 else 0.50

    # Derive shaping parameters
    lo_need = max(0, min(1, 1.0 - low_end_ratio / 0.55))
    lo_gain_db = min(3.0, lo_need * 3.0)
    mid_gain_db = -lo_gain_db * 0.20
    hi_need = max(0, min(1, 1.0 - high_end_ratio / 0.45))
    hi_gain_db = min(2.0, hi_need * 1.8)
    crest_norm = max(0, min(1, (crest_db - 6) / 18))
    warmth_gap = max(-0.2, min(0.5, 0.50 - harmonic_warmth)) / 0.5
    harmonic_drive = min(0.20, max(0, (1 - crest_norm) * 0.6 + max(0, warmth_gap) * 0.4) * 0.20)
    bass_enhance_depth = min(0.35, max(0, lo_need * 0.7 + (1 - crest_norm) * 0.3) * 0.35)
    glue_enabled = crest_db < 14
    transient_attack = max(0.005, min(0.030, 0.010 + crest_norm * 0.020))
    transient_release = max(0.100, min(0.500, 0.150 + crest_norm * 0.250))

    return {
        'spectralCentroid': round(centroid, 1),
        'crestFactor': round(crest_db, 1),
        'lowEndRatio': round(low_end_ratio, 4),
        'highEndRatio': round(high_end_ratio, 4),
        'harmonicWarmthIndex': round(harmonic_warmth, 4),
        'fundamentalFreq': round(f0, 1),
        'loGainDb': round(lo_gain_db, 2),
        'midGainDb': round(mid_gain_db, 2),
        'hiGainDb': round(hi_gain_db, 2),
        'harmonicDrive': round(harmonic_drive, 4),
        'bassEnhanceDepth': round(bass_enhance_depth, 4),
        'glueEnabled': glue_enabled,
        'transientAttack': round(transient_attack, 4),
        'transientRelease': round(transient_release, 4),
    }


def detect_f0(mono, sample_rate, min_f=50, max_f=1000):
    """Detect fundamental frequency via normalized autocorrelation."""
    target_sr = 16000
    ratio = sample_rate / target_sr
    ds_len = int(len(mono) / ratio)
    ds = np.interp(np.arange(ds_len) * ratio, np.arange(len(mono)), mono)

    min_lag = int(target_sr / max_f)
    max_lag = int(target_sr / min_f)
    N = min(len(ds), max_lag + 1)
    if N < max_lag + 2:
        return 0.0

    best_lag = 0
    best_corr = 0.0
    for lag in range(min_lag, max_lag + 1):
        s = np.dot(ds[:N-lag], ds[lag:N-lag+lag]) if lag > 0 else np.dot(ds[:N], ds[:N])
        norm = np.dot(ds[:N], ds[:N])
        corr = s / (norm + 1e-9)
        if corr > best_corr:
            best_corr = corr
            best_lag = lag

    if best_corr < 0.25:
        return 0.0
    return target_sr / best_lag


def compute_etag(file_path):
    """Compute a file hash to use as ETag."""
    h = hashlib.md5()
    with open(file_path, 'rb') as f:
        # Read first 64KB + last 64KB + size for speed
        head = f.read(65536)
        f.seek(-65536, 2)
        tail = f.read(65536)
        size = f.seek(0, 2)
    h.update(head)
    h.update(tail)
    h.update(str(size).encode())
    return h.hexdigest()

print('✓ DSP engine ready')
